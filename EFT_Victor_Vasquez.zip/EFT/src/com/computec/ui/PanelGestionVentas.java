package com.computec.ui;

/*https://toedter.com/jcalendar/*/

import com.computec.conexion.DatabaseConnection;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class PanelGestionVentas extends JPanel {
    private JTable tablaVentas;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private JButton btnBuscar;
    private JButton btnVerDetalles;
    private JButton btnCancelarVenta;
    private JDateChooser fechaInicio;
    private JDateChooser fechaFin;

    public PanelGestionVentas() {
        setLayout(new BorderLayout());

        // Panel superior para búsqueda y filtros
        JPanel panelBusqueda = new JPanel();
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar");
        fechaInicio = new JDateChooser();
        fechaFin = new JDateChooser();
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(new JLabel("Desde:"));
        panelBusqueda.add(fechaInicio);
        panelBusqueda.add(new JLabel("Hasta:"));
        panelBusqueda.add(fechaFin);
        panelBusqueda.add(btnBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // Tabla de ventas
        String[] columnas = {"ID", "Cliente", "Equipo", "Fecha", "Precio"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaVentas = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaVentas);
        add(scrollPane, BorderLayout.CENTER);

        // Panel inferior para botones de acción
        JPanel panelAcciones = new JPanel();
        btnVerDetalles = new JButton("Ver Detalles");
        btnCancelarVenta = new JButton("Cancelar Venta");
        panelAcciones.add(btnVerDetalles);
        panelAcciones.add(btnCancelarVenta);
        add(panelAcciones, BorderLayout.SOUTH);

        // Agregar listeners
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarVentas();
            }
        });

        btnVerDetalles.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verDetallesVenta();
            }
        });

        btnCancelarVenta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarVenta();
            }
        });

        // Cargar todas las ventas al iniciar
        cargarVentas();
    }

    private void cargarVentas() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            String query = "SELECT v.id, c.nombre_completo AS cliente, e.modelo AS equipo, " +
                           "v.fecha_hora, e.precio " +
                           "FROM ventas v " +
                           "JOIN clientes c ON v.cliente_id = c.id " +
                           "JOIN equipos e ON v.equipo_id = e.id " +
                           "ORDER BY v.fecha_hora DESC";
            List<Map<String, Object>> ventas = dbConn.executeQuery(query);
            actualizarTabla(ventas);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al cargar las ventas: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarVentas() {
        String busqueda = txtBuscar.getText().trim();
        Date inicio = fechaInicio.getDate();
        Date fin = fechaFin.getDate();
        
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            StringBuilder queryBuilder = new StringBuilder(
                "SELECT v.id, c.nombre_completo AS cliente, e.modelo AS equipo, v.fecha_hora, e.precio " +
                "FROM ventas v " +
                "JOIN clientes c ON v.cliente_id = c.id " +
                "JOIN equipos e ON v.equipo_id = e.id " +
                "WHERE 1=1 ");

            if (!busqueda.isEmpty()) {
                queryBuilder.append("AND (c.nombre_completo LIKE ? OR e.modelo LIKE ?) ");
            }
            if (inicio != null && fin != null) {
                queryBuilder.append("AND v.fecha_hora BETWEEN ? AND ? ");
            }
            queryBuilder.append("ORDER BY v.fecha_hora DESC");

            List<Object> params = new java.util.ArrayList<>();
            if (!busqueda.isEmpty()) {
                params.add("%" + busqueda + "%");
                params.add("%" + busqueda + "%");
            }
            if (inicio != null && fin != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                params.add(sdf.format(inicio));
                params.add(sdf.format(fin));
            }

            List<Map<String, Object>> ventas = dbConn.executeQuery(queryBuilder.toString(), params.toArray());
            actualizarTabla(ventas);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al buscar ventas: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String formatearPrecio(Object precioObj) {
        if (precioObj instanceof BigDecimal) {
            return String.format("$%.2f", ((BigDecimal) precioObj).doubleValue());
        } else if (precioObj instanceof Double) {
            return String.format("$%.2f", (Double) precioObj);
        } else if (precioObj != null) {
            try {
                double precio = Double.parseDouble(precioObj.toString());
                return String.format("$%.2f", precio);
            } catch (NumberFormatException e) {
                System.err.println("Error al convertir precio: " + e.getMessage());
                return "N/A";
            }
        }
        return "N/A";
    }

    private void actualizarTabla(List<Map<String, Object>> ventas) {
        modeloTabla.setRowCount(0);
        for (Map<String, Object> venta : ventas) {
            Object precioObj = venta.get("precio");
            String precioFormateado = formatearPrecio(precioObj);

            modeloTabla.addRow(new Object[]{
                venta.get("id"),
                venta.get("cliente"),
                venta.get("equipo"),
                venta.get("fecha_hora"),
                precioFormateado
            });
        }
    }

    private void verDetallesVenta() {
        int filaSeleccionada = tablaVentas.getSelectedRow();
        if (filaSeleccionada >= 0) {
            String detalles = "ID: " + tablaVentas.getValueAt(filaSeleccionada, 0) + "\n" +
                              "Cliente: " + tablaVentas.getValueAt(filaSeleccionada, 1) + "\n" +
                              "Equipo: " + tablaVentas.getValueAt(filaSeleccionada, 2) + "\n" +
                              "Fecha: " + tablaVentas.getValueAt(filaSeleccionada, 3) + "\n" +
                              "Precio: " + tablaVentas.getValueAt(filaSeleccionada, 4);
            
            JOptionPane.showMessageDialog(this, detalles, "Detalles de Venta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione una venta para ver sus detalles", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void cancelarVenta() {
        int filaSeleccionada = tablaVentas.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int idVenta = (int) tablaVentas.getValueAt(filaSeleccionada, 0);
            int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de que desea cancelar esta venta?", 
                "Confirmar cancelación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    DatabaseConnection dbConn = DatabaseConnection.getInstance();
                    int filasAfectadas = dbConn.delete("ventas", "id = ?", idVenta);
                    if (filasAfectadas > 0) {
                        JOptionPane.showMessageDialog(this, 
                            "Venta cancelada con éxito", 
                            "Cancelación exitosa", JOptionPane.INFORMATION_MESSAGE);
                        cargarVentas(); // Recargar la tabla
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Error al cancelar la venta: " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione una venta para cancelar", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }
}