package com.computec.ui;

import com.computec.conexion.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;
import java.util.List;

public class PanelReporteEquipos extends JPanel {
    private JTable tablaResumen;
    private DefaultTableModel modeloTabla;
    private JComboBox<String> cmbTipoEquipo;
    private JButton btnGenerar;
    private JPanel panelGraficos;
    private JComboBox<String> cmbTipoGrafico;

    public PanelReporteEquipos() {
        setLayout(new BorderLayout());

        // Panel superior para filtros
        JPanel panelFiltros = new JPanel();
        cmbTipoEquipo = new JComboBox<>(new String[]{"Todos", "Desktop", "Laptop"});
        btnGenerar = new JButton("Generar Reporte");
        cmbTipoGrafico = new JComboBox<>(new String[]{"Equipos por Tipo", "Top 5 Equipos Más Vendidos"});
        panelFiltros.add(new JLabel("Tipo de Equipo:"));
        panelFiltros.add(cmbTipoEquipo);
        panelFiltros.add(cmbTipoGrafico);
        panelFiltros.add(btnGenerar);
        add(panelFiltros, BorderLayout.NORTH);

        // Tabla de resumen
        String[] columnas = {"Modelo", "Tipo", "Cantidad en Stock", "Precio Unitario", "Total Vendidos"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaResumen = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaResumen);
        add(scrollPane, BorderLayout.CENTER);

        // Panel para gráficos
        panelGraficos = new JPanel();
        add(panelGraficos, BorderLayout.SOUTH);

        btnGenerar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        // Generar reporte inicial
        generarReporte();
    }

    private void generarReporte() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            String tipoEquipo = (String) cmbTipoEquipo.getSelectedItem();

            String query = "SELECT e.modelo, e.tipo, e.precio, " +
                           "COUNT(v.id) AS total_vendidos, " +
                           "(SELECT COUNT(*) FROM equipos WHERE modelo = e.modelo) AS cantidad_stock " +
                           "FROM equipos e LEFT JOIN ventas v ON e.id = v.equipo_id ";
            if (!tipoEquipo.equals("Todos")) {
                query += "WHERE e.tipo = ? ";
            }
            query += "GROUP BY e.id ORDER BY total_vendidos DESC";

            List<Object> params = new ArrayList<>();
            if (!tipoEquipo.equals("Todos")) {
                params.add(tipoEquipo.toLowerCase());
            }

            List<Map<String, Object>> resultados = dbConn.executeQuery(query, params.toArray());
            actualizarTabla(resultados);
            actualizarGrafico(resultados);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al generar el reporte: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private double convertirADouble(Object valor) {
        if (valor instanceof BigDecimal) {
            return ((BigDecimal) valor).doubleValue();
        } else if (valor instanceof Double) {
            return (Double) valor;
        } else if (valor instanceof Integer) {
            return ((Integer) valor).doubleValue();
        } else if (valor instanceof Long) {
            return ((Long) valor).doubleValue();
        } else if (valor != null) {
            try {
                return Double.parseDouble(valor.toString());
            } catch (NumberFormatException e) {
                System.err.println("Error al convertir valor a double: " + e.getMessage());
                return 0.0; // O cualquier otro valor predeterminado
            }
        }
        return 0.0; // Valor predeterminado para null
    }

    private void actualizarTabla(List<Map<String, Object>> resultados) {
        modeloTabla.setRowCount(0);
        for (Map<String, Object> resultado : resultados) {
            Object precioObj = resultado.get("precio");
            double precio = convertirADouble(precioObj);

            modeloTabla.addRow(new Object[]{
                resultado.get("modelo"),
                resultado.get("tipo"),
                resultado.get("cantidad_stock"),
                String.format("$%.2f", precio),
                resultado.get("total_vendidos")
            });
        }
    }

    private void actualizarGrafico(List<Map<String, Object>> resultados) {
        panelGraficos.removeAll();
        
        if (cmbTipoGrafico.getSelectedItem().equals("Equipos por Tipo")) {
            SimplePieChart pieChart = new SimplePieChart(resultados, "Distribución de Equipos por Tipo");
            pieChart.setPreferredSize(new Dimension(400, 300));
            panelGraficos.add(pieChart);
        } else {
            SimpleBarChart barChart = new SimpleBarChart(resultados, "Top 5 Equipos Más Vendidos");
            barChart.setPreferredSize(new Dimension(400, 300));
            panelGraficos.add(barChart);
        }
        
        panelGraficos.revalidate();
        panelGraficos.repaint();
    }

    private class SimpleBarChart extends JPanel {
        private List<Map<String, Object>> data;
        private String title;

        public SimpleBarChart(List<Map<String, Object>> data, String title) {
            this.data = data;
            this.title = title;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (data == null || data.isEmpty()) return;

            int width = getWidth();
            int height = getHeight();
            int barWidth = width / Math.min(data.size(), 5);  // Limitamos a los top 5

            // Encuentra el valor máximo para escalar las barras
            double maxValue = data.stream()
                .limit(5)
                .mapToDouble(m -> ((Number)m.get("total_vendidos")).doubleValue())
                .max()
                .orElse(0);

            // Dibuja el título
            g.setColor(Color.BLACK);
            g.drawString(title, 10, 20);

            // Dibuja las barras
            for (int i = 0; i < Math.min(data.size(), 5); i++) {
                Map<String, Object> item = data.get(i);
                double value = ((Number)item.get("total_vendidos")).doubleValue();
                int barHeight = (int)((value / maxValue) * (height - 40));

                g.setColor(Color.BLUE);
                g.fillRect(i * barWidth + 10, height - barHeight - 20, barWidth - 20, barHeight);

                g.setColor(Color.BLACK);
                g.drawString(item.get("modelo").toString(), i * barWidth + 10, height - 5);
                g.drawString(String.format("%.0f", value), i * barWidth + 10, height - barHeight - 25);
            }
        }
    }

    private class SimplePieChart extends JPanel {
        private List<Map<String, Object>> data;
        private String title;

        public SimplePieChart(List<Map<String, Object>> data, String title) {
            this.data = data;
            this.title = title;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (data == null || data.isEmpty()) return;

            int width = getWidth();
            int height = getHeight();
            int diameter = Math.min(width, height) - 40;
            int x = (width - diameter) / 2;
            int y = (height - diameter) / 2;

            // Calcular totales por tipo
            Map<String, Integer> totalesPorTipo = new HashMap<>();
            for (Map<String, Object> item : data) {
                String tipo = (String) item.get("tipo");
                int cantidad = ((Number) item.get("cantidad_stock")).intValue();
                totalesPorTipo.put(tipo, totalesPorTipo.getOrDefault(tipo, 0) + cantidad);
            }

            int total = totalesPorTipo.values().stream().mapToInt(Integer::intValue).sum();

            // Dibuja el título
            g.setColor(Color.BLACK);
            g.drawString(title, 10, 20);

            // Dibuja el gráfico circular
            int startAngle = 0;
            int i = 0;
            Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.ORANGE};
            for (Map.Entry<String, Integer> entry : totalesPorTipo.entrySet()) {
                int arcAngle = (int) Math.round(360.0 * entry.getValue() / total);
                g.setColor(colors[i % colors.length]);
                g.fillArc(x, y, diameter, diameter, startAngle, arcAngle);
                startAngle += arcAngle;
                i++;
            }

            // Dibuja la leyenda
            int legendY = y + diameter + 20;
            i = 0;
            for (Map.Entry<String, Integer> entry : totalesPorTipo.entrySet()) {
                g.setColor(colors[i % colors.length]);
                g.fillRect(10, legendY, 20, 20);
                g.setColor(Color.BLACK);
                g.drawString(entry.getKey() + ": " + entry.getValue(), 35, legendY + 15);
                legendY += 25;
                i++;
            }
        }
    }
}