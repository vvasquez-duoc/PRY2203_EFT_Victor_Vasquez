package com.computec.ui;

import com.computec.conexion.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class PanelRegistroEquipo extends JPanel {
    private JTextField txtModelo;
    private JTextField txtCPU;
    private JTextField txtDiscoDuro;
    private JTextField txtRAM;
    private JTextField txtPrecio;
    private JComboBox<String> cmbTipo;
    private JPanel panelEspecifico;
    private JTextField txtPotenciaFuente;
    private JTextField txtFactorForma;
    private JTextField txtTamanioPantalla;
    private JCheckBox chkEsTouch;
    private JTextField txtPuertosUSB;
    private JButton btnRegistrar;

    public PanelRegistroEquipo() {
        setLayout(new BorderLayout());
        
        JPanel panelGeneral = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Campos generales
        gbc.gridx = 0; gbc.gridy = 0;
        panelGeneral.add(new JLabel("Modelo:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        txtModelo = new JTextField(20);
        panelGeneral.add(txtModelo, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelGeneral.add(new JLabel("CPU:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        txtCPU = new JTextField(20);
        panelGeneral.add(txtCPU, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelGeneral.add(new JLabel("Disco Duro (MB):"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        txtDiscoDuro = new JTextField(20);
        panelGeneral.add(txtDiscoDuro, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panelGeneral.add(new JLabel("RAM (GB):"), gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        txtRAM = new JTextField(20);
        panelGeneral.add(txtRAM, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panelGeneral.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        txtPrecio = new JTextField(20);
        panelGeneral.add(txtPrecio, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        panelGeneral.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1; gbc.gridy = 5;
        cmbTipo = new JComboBox<>(new String[]{"Desktop", "Laptop"});
        panelGeneral.add(cmbTipo, gbc);

        add(panelGeneral, BorderLayout.NORTH);

        // Panel para campos específicos
        panelEspecifico = new JPanel(new CardLayout());
        JPanel panelDesktop = crearPanelDesktop();
        JPanel panelLaptop = crearPanelLaptop();
        panelEspecifico.add(panelDesktop, "Desktop");
        panelEspecifico.add(panelLaptop, "Laptop");
        add(panelEspecifico, BorderLayout.CENTER);

        cmbTipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout)(panelEspecifico.getLayout());
                cl.show(panelEspecifico, (String)cmbTipo.getSelectedItem());
            }
        });

        btnRegistrar = new JButton("Registrar Equipo");
        add(btnRegistrar, BorderLayout.SOUTH);

        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarEquipo();
            }
        });
    }

    private JPanel crearPanelDesktop() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Potencia Fuente:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        txtPotenciaFuente = new JTextField(20);
        panel.add(txtPotenciaFuente, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Factor Forma:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        txtFactorForma = new JTextField(20);
        panel.add(txtFactorForma, gbc);

        return panel;
    }

    private JPanel crearPanelLaptop() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Tamaño Pantalla:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        txtTamanioPantalla = new JTextField(20);
        panel.add(txtTamanioPantalla, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Es Touch:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        chkEsTouch = new JCheckBox();
        panel.add(chkEsTouch, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Puertos USB:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        txtPuertosUSB = new JTextField(20);
        panel.add(txtPuertosUSB, gbc);

        return panel;
    }

    private void registrarEquipo() {
        if (camposValidos()) {
            try {
                DatabaseConnection dbConn = DatabaseConnection.getInstance();
                
                Map<String, Object> equipoData = new HashMap<>();
                equipoData.put("modelo", txtModelo.getText());
                equipoData.put("cpu", txtCPU.getText());
                equipoData.put("disco_duro", Integer.parseInt(txtDiscoDuro.getText()));
                equipoData.put("ram", Integer.parseInt(txtRAM.getText()));
                equipoData.put("precio", Double.parseDouble(txtPrecio.getText()));
                equipoData.put("tipo", cmbTipo.getSelectedItem().toString().toLowerCase());

                int newEquipoId = dbConn.insert("equipos", equipoData);

                // Insertar datos específicos según el tipo de equipo
                if (cmbTipo.getSelectedItem().toString().equals("Desktop")) {
                    Map<String, Object> desktopData = new HashMap<>();
                    desktopData.put("id", newEquipoId);
                    desktopData.put("potencia_fuente", Integer.parseInt(txtPotenciaFuente.getText()));
                    desktopData.put("factor_forma", txtFactorForma.getText());
                    dbConn.insert("desktops", desktopData);
                } else {
                    Map<String, Object> laptopData = new HashMap<>();
                    laptopData.put("id", newEquipoId);
                    laptopData.put("tamanio_pantalla", Double.parseDouble(txtTamanioPantalla.getText()));
                    laptopData.put("es_touch", chkEsTouch.isSelected());
                    laptopData.put("puertos_usb", Integer.parseInt(txtPuertosUSB.getText()));
                    dbConn.insert("laptops", laptopData);
                }

                JOptionPane.showMessageDialog(this, 
                    "Equipo registrado con éxito. ID: " + newEquipoId, 
                    "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);

                limpiarCampos();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al registrar el equipo: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error en el formato de los datos numéricos.", 
                    "Error de Formato", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean camposValidos() {
        // Validación básica, puedes expandir esto según tus necesidades
        if (txtModelo.getText().isEmpty() || txtCPU.getText().isEmpty() ||
            txtDiscoDuro.getText().isEmpty() || txtRAM.getText().isEmpty() ||
            txtPrecio.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Todos los campos generales son obligatorios", 
                "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (cmbTipo.getSelectedItem().toString().equals("Desktop")) {
            if (txtPotenciaFuente.getText().isEmpty() || txtFactorForma.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Todos los campos de Desktop son obligatorios", 
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } else {
            if (txtTamanioPantalla.getText().isEmpty() || txtPuertosUSB.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Todos los campos de Laptop son obligatorios", 
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        return true;
    }

    private void limpiarCampos() {
        txtModelo.setText("");
        txtCPU.setText("");
        txtDiscoDuro.setText("");
        txtRAM.setText("");
        txtPrecio.setText("");
        txtPotenciaFuente.setText("");
        txtFactorForma.setText("");
        txtTamanioPantalla.setText("");
        chkEsTouch.setSelected(false);
        txtPuertosUSB.setText("");
    }
}