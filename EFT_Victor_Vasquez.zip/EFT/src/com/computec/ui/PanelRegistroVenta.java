package com.computec.ui;

import com.computec.conexion.DatabaseConnection;
import com.computec.model.Cliente;
import com.computec.model.Equipo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PanelRegistroVenta extends JPanel {
    private JComboBox<String> cmbClientes;
    private JComboBox<String> cmbEquipos;
    private JTextField txtFecha;
    private JTextField txtPrecio;
    private JButton btnRegistrar;

    private Map<String, Integer> clientesMap = new HashMap<>();
    private Map<String, Integer> equiposMap = new HashMap<>();

    public PanelRegistroVenta() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Cliente:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        cmbClientes = new JComboBox<>();
        add(cmbClientes, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Equipo:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        cmbEquipos = new JComboBox<>();
        add(cmbEquipos, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Fecha:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        txtFecha = new JTextField(10);
        txtFecha.setEditable(false);
        txtFecha.setText(java.time.LocalDate.now().toString()); // Fecha actual
        add(txtFecha, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        txtPrecio = new JTextField(10);
        txtPrecio.setEditable(false);
        add(txtPrecio, gbc);

        gbc.gridx = 1; gbc.gridy = 4;
        btnRegistrar = new JButton("Registrar Venta");
        add(btnRegistrar, gbc);

        cargarClientes();
        cargarEquipos();

        cmbEquipos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarPrecio();
            }
        });

        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarVenta();
            }
        });
    }

    private void cargarClientes() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            List<Map<String, Object>> clientes = dbConn.select("clientes", null);
            for (Map<String, Object> cliente : clientes) {
                String nombreCliente = cliente.get("nombre_completo") + " (" + cliente.get("rut") + ")";
                cmbClientes.addItem(nombreCliente);
                clientesMap.put(nombreCliente, (Integer) cliente.get("id"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al cargar los clientes: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarEquipos() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            List<Map<String, Object>> equipos = dbConn.select("equipos", null);
            for (Map<String, Object> equipo : equipos) {
                String nombreEquipo = equipo.get("modelo") + " (" + equipo.get("tipo") + ")";
                cmbEquipos.addItem(nombreEquipo);
                equiposMap.put(nombreEquipo, (Integer) equipo.get("id"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al cargar los equipos: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarPrecio() {
        String equipoSeleccionado = (String) cmbEquipos.getSelectedItem();
        if (equipoSeleccionado != null) {
            try {
                DatabaseConnection dbConn = DatabaseConnection.getInstance();
                int equipoId = equiposMap.get(equipoSeleccionado);
                List<Map<String, Object>> resultado = dbConn.select("equipos", "id = ?", equipoId);
                if (!resultado.isEmpty()) {
                    Object precioObj = resultado.get(0).get("precio");
                    double precio;
                    if (precioObj instanceof BigDecimal) {
                        precio = ((BigDecimal) precioObj).doubleValue();
                    } else if (precioObj instanceof Double) {
                        precio = (Double) precioObj;
                    } else {
                        precio = Double.parseDouble(precioObj.toString());
                    }
                    txtPrecio.setText(String.format("%.2f", precio));
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al obtener el precio del equipo: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al convertir el precio: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void registrarVenta() {
        String clienteSeleccionado = (String) cmbClientes.getSelectedItem();
        String equipoSeleccionado = (String) cmbEquipos.getSelectedItem();

        if (clienteSeleccionado == null || equipoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un cliente y un equipo", 
                "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            Map<String, Object> ventaData = new HashMap<>();
            ventaData.put("cliente_id", clientesMap.get(clienteSeleccionado));
            ventaData.put("equipo_id", equiposMap.get(equipoSeleccionado));
            ventaData.put("fecha_hora", java.time.LocalDateTime.now().toString());

            int newVentaId = dbConn.insert("ventas", ventaData);

            JOptionPane.showMessageDialog(this, 
                "Venta registrada con éxito. ID: " + newVentaId, 
                "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);

            limpiarCampos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al registrar la venta: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        cmbClientes.setSelectedIndex(0);
        cmbEquipos.setSelectedIndex(0);
        txtFecha.setText(java.time.LocalDate.now().toString());
        txtPrecio.setText("");
    }
}