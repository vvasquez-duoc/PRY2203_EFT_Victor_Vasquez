package com.computec.ui;

import com.computec.model.Cliente;
import com.computec.conexion.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class PanelRegistroCliente extends JPanel {
    private JTextField txtRut;
    private JTextField txtNombreCompleto;
    private JTextField txtDireccion;
    private JTextField txtComuna;
    private JTextField txtCorreoElectronico;
    private JTextField txtTelefono;
    private JButton btnRegistrar;

    public PanelRegistroCliente() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Crear y añadir componentes
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("RUT:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        txtRut = new JTextField(20);
        add(txtRut, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Nombre Completo:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        txtNombreCompleto = new JTextField(20);
        add(txtNombreCompleto, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Dirección:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        txtDireccion = new JTextField(20);
        add(txtDireccion, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Comuna:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        txtComuna = new JTextField(20);
        add(txtComuna, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Correo Electrónico:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        txtCorreoElectronico = new JTextField(20);
        add(txtCorreoElectronico, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("Teléfono:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        txtTelefono = new JTextField(20);
        add(txtTelefono, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        btnRegistrar = new JButton("Registrar Cliente");
        add(btnRegistrar, gbc);

        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarCliente();
            }
        });
    }

    private void registrarCliente() {
        // Validar campos
        if (camposValidos()) {
            try {
                DatabaseConnection dbConn = DatabaseConnection.getInstance();
                
                Map<String, Object> clienteData = new HashMap<>();
                clienteData.put("rut", txtRut.getText());
                clienteData.put("nombre_completo", txtNombreCompleto.getText());
                clienteData.put("direccion", txtDireccion.getText());
                clienteData.put("comuna", txtComuna.getText());
                clienteData.put("correo_electronico", txtCorreoElectronico.getText());
                clienteData.put("telefono", txtTelefono.getText());

                int newClientId = dbConn.insert("clientes", clienteData);

                JOptionPane.showMessageDialog(this, 
                    "Cliente registrado con éxito. ID: " + newClientId, 
                    "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);

                limpiarCampos();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al registrar el cliente: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean camposValidos() {
        if (txtRut.getText().isEmpty() || txtNombreCompleto.getText().isEmpty() ||
            txtDireccion.getText().isEmpty() || txtComuna.getText().isEmpty() ||
            txtCorreoElectronico.getText().isEmpty() || txtTelefono.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Todos los campos son obligatorios", 
                "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Aquí puedes añadir más validaciones específicas si es necesario
        return true;
    }

    private void limpiarCampos() {
        txtRut.setText("");
        txtNombreCompleto.setText("");
        txtDireccion.setText("");
        txtComuna.setText("");
        txtCorreoElectronico.setText("");
        txtTelefono.setText("");
    }
}