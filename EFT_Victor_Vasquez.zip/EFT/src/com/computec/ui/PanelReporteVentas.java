package com.computec.ui;

/*https://toedter.com/jcalendar/*/

import com.computec.conexion.DatabaseConnection;
import com.toedter.calendar.JDateChooser;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class PanelReporteVentas extends JPanel {
    private JTable tablaResumen;
    private DefaultTableModel modeloTabla;
    private JDateChooser fechaInicio;
    private JDateChooser fechaFin;
    private JButton btnGenerar;
    private JPanel panelGraficos;

    public PanelReporteVentas() {
        setLayout(new BorderLayout());

        // Panel superior para filtros
        JPanel panelFiltros = new JPanel();
        fechaInicio = new JDateChooser();
        fechaFin = new JDateChooser();
        btnGenerar = new JButton("Generar Reporte");
        panelFiltros.add(new JLabel("Desde:"));
        panelFiltros.add(fechaInicio);
        panelFiltros.add(new JLabel("Hasta:"));
        panelFiltros.add(fechaFin);
        panelFiltros.add(btnGenerar);
        add(panelFiltros, BorderLayout.NORTH);

        // Tabla de resumen
        String[] columnas = {"Período", "Cantidad de Ventas", "Total Ventas"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaResumen = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaResumen);
        add(scrollPane, BorderLayout.CENTER);

        // Panel para gráficos
        panelGraficos = new JPanel();
        add(panelGraficos, BorderLayout.SOUTH);

        btnGenerar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        // Generar reporte inicial
        generarReporte();
    }
    
    private void actualizarGrafico(List<Map<String, Object>> resultados) {
        panelGraficos.removeAll();
        
        SimpleBarChart chart = new SimpleBarChart(resultados, "Ventas por Mes");
        chart.setPreferredSize(new Dimension(400, 300));
        panelGraficos.add(chart);
        
        panelGraficos.revalidate();
        panelGraficos.repaint();
    }

    private void generarReporte() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fechaInicioStr = fechaInicio.getDate() != null ? sdf.format(fechaInicio.getDate()) : null;
            String fechaFinStr = fechaFin.getDate() != null ? sdf.format(fechaFin.getDate()) : null;

            String query = "SELECT DATE_FORMAT(v.fecha_hora, '%Y-%m') AS periodo, " +
                           "COUNT(*) AS cantidad_ventas, SUM(e.precio) AS total_ventas " +
                           "FROM ventas v JOIN equipos e ON v.equipo_id = e.id ";
            if (fechaInicioStr != null && fechaFinStr != null) {
                query += "WHERE v.fecha_hora BETWEEN ? AND ? ";
            }
            query += "GROUP BY periodo ORDER BY periodo";

            List<Object> params = new ArrayList<>();
            if (fechaInicioStr != null && fechaFinStr != null) {
                params.add(fechaInicioStr);
                params.add(fechaFinStr);
            }

            List<Map<String, Object>> resultados = dbConn.executeQuery(query, params.toArray());
            actualizarTabla(resultados);
            actualizarGrafico(resultados);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al generar el reporte: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarTabla(List<Map<String, Object>> resultados) {
        modeloTabla.setRowCount(0);
        for (Map<String, Object> resultado : resultados) {
            Object totalVentasObj = resultado.get("total_ventas");
            double totalVentas;

            if (totalVentasObj instanceof BigDecimal) {
                totalVentas = ((BigDecimal) totalVentasObj).doubleValue();
            } else if (totalVentasObj instanceof Double) {
                totalVentas = (Double) totalVentasObj;
            } else {
                // Si no es BigDecimal ni Double, intentamos convertirlo a String y luego a Double
                totalVentas = Double.parseDouble(totalVentasObj.toString());
            }

            modeloTabla.addRow(new Object[]{
                resultado.get("periodo"),
                resultado.get("cantidad_ventas"),
                String.format("$%.2f", totalVentas)
            });
        }
    }
}