package com.computec.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private JPanel panelContenido;

    public VentanaPrincipal() {
        configurarVentana();
        crearComponentes();
    }

    private void configurarVentana() {
        setTitle("Sistema de Ventas Computec");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void crearComponentes() {
        // Crear barra de menú
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // Menú Clientes
        JMenu menuClientes = new JMenu("Clientes");
        menuBar.add(menuClientes);
        JMenuItem itemRegistrarCliente = new JMenuItem("Registrar Cliente");
        JMenuItem itemGestionarClientes = new JMenuItem("Gestionar Clientes");
        menuClientes.add(itemRegistrarCliente);
        menuClientes.add(itemGestionarClientes);

        // Menú Equipos
        JMenu menuEquipos = new JMenu("Equipos");
        menuBar.add(menuEquipos);
        JMenuItem itemRegistrarEquipo = new JMenuItem("Registrar Equipo");
        JMenuItem itemGestionarEquipos = new JMenuItem("Gestionar Equipos");
        menuEquipos.add(itemRegistrarEquipo);
        menuEquipos.add(itemGestionarEquipos);

        // Menú Ventas
        JMenu menuVentas = new JMenu("Ventas");
        menuBar.add(menuVentas);
        JMenuItem itemRegistrarVenta = new JMenuItem("Registrar Venta");
        JMenuItem itemGestionarVentas = new JMenuItem("Gestionar Ventas");
        menuVentas.add(itemRegistrarVenta);
        menuVentas.add(itemGestionarVentas);

        // Menú Reportes
        JMenu menuReportes = new JMenu("Reportes");
        menuBar.add(menuReportes);
        JMenuItem itemReporteVentas = new JMenuItem("Reporte de Ventas");
        JMenuItem itemReporteEquipos = new JMenuItem("Reporte de Equipos");
        menuReportes.add(itemReporteVentas);
        menuReportes.add(itemReporteEquipos);

        // Panel de contenido principal
        panelContenido = new JPanel();
        panelContenido.setLayout(new BorderLayout());
        setContentPane(panelContenido);

        // Etiqueta de bienvenida
        JLabel labelBienvenida = new JLabel("Bienvenido al Sistema de Ventas Computec", SwingConstants.CENTER);
        labelBienvenida.setFont(new Font("Arial", Font.BOLD, 20));
        panelContenido.add(labelBienvenida, BorderLayout.CENTER);

        // Agregar ActionListeners a los items del menú
        itemRegistrarCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelRegistroCliente();
            }
        });

        itemGestionarClientes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelGestionClientes();
            }
        });

        itemRegistrarEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelRegistroEquipo();
            }
        });

        itemGestionarEquipos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelGestionEquipos();
            }
        });

        itemRegistrarVenta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelRegistroVenta();
            }
        });

        itemGestionarVentas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelGestionVentas();
            }
        });

        itemReporteVentas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarReporteVentas();
            }
        });

        itemReporteEquipos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarReporteEquipos();
            }
        });
    }

    private void mostrarPanelRegistroCliente() {
        panelContenido.removeAll();
        panelContenido.add(new PanelRegistroCliente(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelGestionClientes() {
        panelContenido.removeAll();
        panelContenido.add(new PanelGestionClientes(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelRegistroEquipo() {
        panelContenido.removeAll();
        panelContenido.add(new PanelRegistroEquipo(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelGestionEquipos() {
        panelContenido.removeAll();
        panelContenido.add(new PanelGestionEquipos(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelRegistroVenta() {
        panelContenido.removeAll();
        panelContenido.add(new PanelRegistroVenta(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelGestionVentas() {
        panelContenido.removeAll();
        panelContenido.add(new PanelGestionVentas(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarReporteVentas() {
        panelContenido.removeAll();
        panelContenido.add(new PanelReporteVentas(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarReporteEquipos() {
        panelContenido.removeAll();
        panelContenido.add(new PanelReporteEquipos(), BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }
}