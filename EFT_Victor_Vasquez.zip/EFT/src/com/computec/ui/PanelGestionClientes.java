package com.computec.ui;

import com.computec.model.Cliente;
import com.computec.conexion.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class PanelGestionClientes extends JPanel {
    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private JButton btnBuscar;
    private JButton btnEditar;
    private JButton btnEliminar;

    public PanelGestionClientes() {
        setLayout(new BorderLayout());

        // Panel superior para búsqueda
        JPanel panelBusqueda = new JPanel();
        txtBuscar = new JTextField(20);
        btnBuscar = new JButton("Buscar");
        panelBusqueda.add(new JLabel("Buscar por RUT o Nombre:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // Tabla de clientes
        String[] columnas = {"ID", "RUT", "Nombre Completo", "Dirección", "Comuna", "Correo Electrónico", "Teléfono"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaClientes = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        add(scrollPane, BorderLayout.CENTER);

        // Panel inferior para botones de acción
        JPanel panelAcciones = new JPanel();
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        panelAcciones.add(btnEditar);
        panelAcciones.add(btnEliminar);
        add(panelAcciones, BorderLayout.SOUTH);

        // Agregar listeners
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarClientes();
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarClienteSeleccionado();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarClienteSeleccionado();
            }
        });

        // Cargar todos los clientes al iniciar
        cargarClientes();
    }

    private void cargarClientes() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            List<Map<String, Object>> clientes = dbConn.select("clientes", null);
            actualizarTabla(clientes);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al cargar los clientes: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarClientes() {
        String busqueda = txtBuscar.getText().trim();
        if (!busqueda.isEmpty()) {
            try {
                DatabaseConnection dbConn = DatabaseConnection.getInstance();
                List<Map<String, Object>> clientes = dbConn.select("clientes", 
                    "rut LIKE ? OR nombre_completo LIKE ?", 
                    "%" + busqueda + "%", "%" + busqueda + "%");
                actualizarTabla(clientes);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error al buscar clientes: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            cargarClientes();
        }
    }

    private void actualizarTabla(List<Map<String, Object>> clientes) {
        modeloTabla.setRowCount(0);
        for (Map<String, Object> cliente : clientes) {
            modeloTabla.addRow(new Object[]{
                cliente.get("id"),
                cliente.get("rut"),
                cliente.get("nombre_completo"),
                cliente.get("direccion"),
                cliente.get("comuna"),
                cliente.get("correo_electronico"),
                cliente.get("telefono")
            });
        }
    }

    private void editarClienteSeleccionado() {
        int filaSeleccionada = tablaClientes.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int idCliente = (int) tablaClientes.getValueAt(filaSeleccionada, 0);
            // Aquí deberías abrir un nuevo diálogo o panel para editar el cliente
            JOptionPane.showMessageDialog(this, 
                "Funcionalidad de edición para el cliente con ID: " + idCliente + " en desarrollo", 
                "Editar Cliente", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un cliente para editar", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminarClienteSeleccionado() {
        int filaSeleccionada = tablaClientes.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int idCliente = (int) tablaClientes.getValueAt(filaSeleccionada, 0);
            int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de que desea eliminar este cliente?", 
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    DatabaseConnection dbConn = DatabaseConnection.getInstance();
                    int filasAfectadas = dbConn.delete("clientes", "id = ?", idCliente);
                    if (filasAfectadas > 0) {
                        JOptionPane.showMessageDialog(this, 
                            "Cliente eliminado con éxito", 
                            "Eliminación exitosa", JOptionPane.INFORMATION_MESSAGE);
                        cargarClientes(); // Recargar la tabla
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Error al eliminar el cliente: " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un cliente para eliminar", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }
}