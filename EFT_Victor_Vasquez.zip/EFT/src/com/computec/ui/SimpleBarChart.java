package com.computec.ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

public class SimpleBarChart extends JPanel {
    private List<Map<String, Object>> data;
    private String title;

    public SimpleBarChart(List<Map<String, Object>> data, String title) {
        this.data = data;
        this.title = title;
        setPreferredSize(new Dimension(400, 300));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (data == null || data.isEmpty()) return;

        int width = getWidth();
        int height = getHeight();
        int barWidth = width / data.size();

        // Encuentra el valor máximo para escalar las barras
        double maxValue = data.stream()
            .mapToDouble(m -> ((Number)m.get("total_ventas")).doubleValue())
            .max()
            .orElse(0);

        // Dibuja el título
        g.setColor(Color.BLACK);
        g.drawString(title, 10, 20);

        // Dibuja las barras
        for (int i = 0; i < data.size(); i++) {
            Map<String, Object> item = data.get(i);
            double value = ((Number)item.get("total_ventas")).doubleValue();
            int barHeight = (int)((value / maxValue) * (height - 40));

            g.setColor(Color.BLUE);
            g.fillRect(i * barWidth + 10, height - barHeight - 20, barWidth - 20, barHeight);

            g.setColor(Color.BLACK);
            g.drawString(item.get("periodo").toString(), i * barWidth + 10, height - 5);
        }
    }
}