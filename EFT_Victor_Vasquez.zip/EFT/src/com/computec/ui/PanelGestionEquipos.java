package com.computec.ui;

import com.computec.conexion.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class PanelGestionEquipos extends JPanel {
    private JTable tablaEquipos;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private JButton btnBuscar;
    private JButton btnEditar;
    private JButton btnEliminar;
    private JComboBox<String> cmbTipoEquipo;

    public PanelGestionEquipos() {
        setLayout(new BorderLayout());

        // Panel superior para búsqueda y filtro
        JPanel panelBusqueda = new JPanel();
        txtBuscar = new JTextField(20);
        btnBuscar = new JButton("Buscar");
        cmbTipoEquipo = new JComboBox<>(new String[]{"Todos", "Desktop", "Laptop"});
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(new JLabel("Tipo:"));
        panelBusqueda.add(cmbTipoEquipo);
        add(panelBusqueda, BorderLayout.NORTH);

        // Tabla de equipos
        String[] columnas = {"ID", "Modelo", "CPU", "Disco Duro (MB)", "RAM (GB)", "Precio", "Tipo", "Detalles Específicos"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaEquipos = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaEquipos);
        add(scrollPane, BorderLayout.CENTER);

        // Panel inferior para botones de acción
        JPanel panelAcciones = new JPanel();
        btnEditar = new JButton("Editar");
        btnEliminar = new JButton("Eliminar");
        panelAcciones.add(btnEditar);
        panelAcciones.add(btnEliminar);
        add(panelAcciones, BorderLayout.SOUTH);

        // Agregar listeners
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarEquipos();
            }
        });

        cmbTipoEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarEquipos();
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarEquipoSeleccionado();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEquipoSeleccionado();
            }
        });

        // Cargar todos los equipos al iniciar
        cargarEquipos();
    }

    private void cargarEquipos() {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            List<Map<String, Object>> equipos = dbConn.select("equipos", null);
            actualizarTabla(equipos);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al cargar los equipos: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarEquipos() {
        String busqueda = txtBuscar.getText().trim();
        String tipoSeleccionado = (String) cmbTipoEquipo.getSelectedItem();
        
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            String whereClause = "";
            List<Object> params = new java.util.ArrayList<>();

            if (!busqueda.isEmpty()) {
                whereClause += "modelo LIKE ? OR cpu LIKE ?";
                params.add("%" + busqueda + "%");
                params.add("%" + busqueda + "%");
            }

            if (!tipoSeleccionado.equals("Todos")) {
                if (!whereClause.isEmpty()) {
                    whereClause += " AND ";
                }
                whereClause += "tipo = ?";
                params.add(tipoSeleccionado.toLowerCase());
            }

            List<Map<String, Object>> equipos = dbConn.select("equipos", whereClause.isEmpty() ? null : whereClause, params.toArray());
            actualizarTabla(equipos);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al buscar equipos: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarTabla(List<Map<String, Object>> equipos) {
        modeloTabla.setRowCount(0);
        for (Map<String, Object> equipo : equipos) {
            String detallesEspecificos = obtenerDetallesEspecificos((int)equipo.get("id"), (String)equipo.get("tipo"));
            modeloTabla.addRow(new Object[]{
                equipo.get("id"),
                equipo.get("modelo"),
                equipo.get("cpu"),
                equipo.get("disco_duro"),
                equipo.get("ram"),
                equipo.get("precio"),
                equipo.get("tipo"),
                detallesEspecificos
            });
        }
    }

    private String obtenerDetallesEspecificos(int id, String tipo) {
        try {
            DatabaseConnection dbConn = DatabaseConnection.getInstance();
            List<Map<String, Object>> detalles;
            if ("desktop".equals(tipo)) {
                detalles = dbConn.select("desktops", "id = ?", id);
                if (!detalles.isEmpty()) {
                    Map<String, Object> desktop = detalles.get(0);
                    return "Potencia: " + desktop.get("potencia_fuente") + "W, Forma: " + desktop.get("factor_forma");
                }
            } else if ("laptop".equals(tipo)) {
                detalles = dbConn.select("laptops", "id = ?", id);
                if (!detalles.isEmpty()) {
                    Map<String, Object> laptop = detalles.get(0);
                    return "Pantalla: " + laptop.get("tamanio_pantalla") + "\", Touch: " + 
                           (((Boolean)laptop.get("es_touch")) ? "Sí" : "No") + ", USB: " + laptop.get("puertos_usb");
                }
            }
        } catch (SQLException ex) {
            return "Error al obtener detalles";
        }
        return "";
    }

    private void editarEquipoSeleccionado() {
        int filaSeleccionada = tablaEquipos.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int idEquipo = (int) tablaEquipos.getValueAt(filaSeleccionada, 0);
            // Aquí deberías abrir un nuevo diálogo o panel para editar el equipo
            JOptionPane.showMessageDialog(this, 
                "Funcionalidad de edición para el equipo con ID: " + idEquipo + " en desarrollo", 
                "Editar Equipo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un equipo para editar", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminarEquipoSeleccionado() {
        int filaSeleccionada = tablaEquipos.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int idEquipo = (int) tablaEquipos.getValueAt(filaSeleccionada, 0);
            String tipoEquipo = (String) tablaEquipos.getValueAt(filaSeleccionada, 6);
            int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de que desea eliminar este equipo?", 
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    DatabaseConnection dbConn = DatabaseConnection.getInstance();
                    // Primero eliminamos de la tabla específica (desktop o laptop)
                    dbConn.delete(tipoEquipo + "s", "id = ?", idEquipo);
                    // Luego eliminamos de la tabla general de equipos
                    int filasAfectadas = dbConn.delete("equipos", "id = ?", idEquipo);
                    if (filasAfectadas > 0) {
                        JOptionPane.showMessageDialog(this, 
                            "Equipo eliminado con éxito", 
                            "Eliminación exitosa", JOptionPane.INFORMATION_MESSAGE);
                        cargarEquipos(); // Recargar la tabla
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Error al eliminar el equipo: " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Por favor, seleccione un equipo para eliminar", 
                "Selección requerida", JOptionPane.WARNING_MESSAGE);
        }
    }
}