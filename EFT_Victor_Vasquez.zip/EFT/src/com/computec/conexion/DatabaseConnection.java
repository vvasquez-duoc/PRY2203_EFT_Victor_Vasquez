package com.computec.conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;
    private String url = "jdbc:mysql://localhost:3306/computec_ventas";
    private String username = "admin";
    private String password = "jy{Sf*%$]C:0v1U}";

    // Constructor privado para prevenir instanciación directa
    private DatabaseConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Database Connection Creation Failed : " + ex.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }

    // Método estático para obtener la instancia
    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    // Método para cerrar la conexión
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.out.println("Error closing the database connection: " + e.getMessage());
            }
        }
    }

    // Métodos CRUD (los mismos que teníamos antes)

    // Método genérico para insertar datos
    public int insert(String table, Map<String, Object> columnValues) throws SQLException {
        StringBuilder columns = new StringBuilder();
        StringBuilder values = new StringBuilder();
        List<Object> valueList = new ArrayList<>();

        for (Map.Entry<String, Object> entry : columnValues.entrySet()) {
            columns.append(entry.getKey()).append(",");
            values.append("?,");
            valueList.add(entry.getValue());
        }

        columns.setLength(columns.length() - 1);
        values.setLength(values.length() - 1);

        String sql = "INSERT INTO " + table + " (" + columns + ") VALUES (" + values + ")";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            int i = 1;
            for (Object value : valueList) {
                pstmt.setObject(i++, value);
            }

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating record failed, no rows affected.");
            }

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    // Solución alternativa: obtener el último ID insertado
                    try (Statement stmt = connection.createStatement()) {
                        ResultSet rs = stmt.executeQuery("SELECT LAST_INSERT_ID()");
                        if (rs.next()) {
                            return rs.getInt(1);
                        } else {
                            throw new SQLException("Creating record failed, no ID obtained.");
                        }
                    }
                }
            }
        }
    }

    // Método genérico para leer datos
    public List<Map<String, Object>> select(String table, String whereClause, Object... params) throws SQLException {
        String sql = "SELECT * FROM " + table;
        if (whereClause != null && !whereClause.isEmpty()) {
            sql += " WHERE " + whereClause;
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                List<Map<String, Object>> results = new ArrayList<>();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();

                while (rs.next()) {
                    Map<String, Object> row = new java.util.HashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.put(metaData.getColumnName(i), rs.getObject(i));
                    }
                    results.add(row);
                }
                return results;
            }
        }
    }

    // Método genérico para actualizar datos
    public int update(String table, Map<String, Object> columnValues, String whereClause, Object... params) throws SQLException {
        StringBuilder setClause = new StringBuilder();
        List<Object> valueList = new ArrayList<>();

        for (Map.Entry<String, Object> entry : columnValues.entrySet()) {
            setClause.append(entry.getKey()).append(" = ?,");
            valueList.add(entry.getValue());
        }

        setClause.setLength(setClause.length() - 1);

        String sql = "UPDATE " + table + " SET " + setClause;
        if (whereClause != null && !whereClause.isEmpty()) {
            sql += " WHERE " + whereClause;
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            int i = 1;
            for (Object value : valueList) {
                pstmt.setObject(i++, value);
            }
            for (Object param : params) {
                pstmt.setObject(i++, param);
            }

            return pstmt.executeUpdate();
        }
    }

    // Método genérico para eliminar datos
    public int delete(String table, String whereClause, Object... params) throws SQLException {
        String sql = "DELETE FROM " + table;
        if (whereClause != null && !whereClause.isEmpty()) {
            sql += " WHERE " + whereClause;
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }

            return pstmt.executeUpdate();
        }
    }
    
    public List<Map<String, Object>> executeQuery(String query, Object... params) throws SQLException {
        List<Map<String, Object>> resultList = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Establecer los parámetros
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            
            // Ejecutar la consulta
            try (ResultSet rs = pstmt.executeQuery()) {
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                // Procesar los resultados
                while (rs.next()) {
                    Map<String, Object> row = new HashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.put(metaData.getColumnName(i), rs.getObject(i));
                    }
                    resultList.add(row);
                }
            }
        }
        return resultList;
    }
}