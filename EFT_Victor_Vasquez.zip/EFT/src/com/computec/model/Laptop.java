package com.computec.model;

public class Laptop extends Equipo {
    private double tamanioPantalla;
    private boolean esTouch;
    private int puertosUsb;

    public Laptop(int id, String modelo, String cpu, int discoDuro, int ram, double precio, double tamanioPantalla, boolean esTouch, int puertosUsb) {
        super(id, modelo, cpu, discoDuro, ram, precio);
        this.tamanioPantalla = tamanioPantalla;
        this.esTouch = esTouch;
        this.puertosUsb = puertosUsb;
    }

    public double getTamanioPantalla() {
        return tamanioPantalla;
    }

    public void setTamanioPantalla(double tamanioPantalla) {
        this.tamanioPantalla = tamanioPantalla;
    }

    public boolean isEsTouch() {
        return esTouch;
    }

    public void setEsTouch(boolean esTouch) {
        this.esTouch = esTouch;
    }

    public int getPuertosUsb() {
        return puertosUsb;
    }

    public void setPuertosUsb(int puertosUsb) {
        this.puertosUsb = puertosUsb;
    }

    @Override
    public String toString() {
        return "Laptop{" +
                super.toString() +
                ", tamanioPantalla=" + tamanioPantalla +
                ", esTouch=" + esTouch +
                ", puertosUsb=" + puertosUsb +
                '}';
    }
}