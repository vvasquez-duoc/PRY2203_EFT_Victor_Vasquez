package com.computec.model;

import com.computec.ventas.*;
import java.time.LocalDateTime;

public class Venta {
    private int id;
    private Cliente cliente;
    private Equipo equipo;
    private LocalDateTime fechaHora;
    private Descuento descuento;

    // Constructor
    public Venta(int id, Cliente cliente, Equipo equipo, LocalDateTime fechaHora) {
        this.id = id;
        this.cliente = cliente;
        this.equipo = equipo;
        this.fechaHora = fechaHora;
        this.descuento = new SinDescuento(); // Por defecto, sin descuento
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }
    
    public void setDescuento(Descuento descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        return "Venta{" +
                "id=" + id +
                ", cliente=" + cliente +
                ", equipo=" + equipo +
                ", fechaHora=" + fechaHora +
                '}';
    }
    
    public double calcularPrecioFinal() {
        return descuento.aplicarDescuento(equipo.getPrecio());
    }
}