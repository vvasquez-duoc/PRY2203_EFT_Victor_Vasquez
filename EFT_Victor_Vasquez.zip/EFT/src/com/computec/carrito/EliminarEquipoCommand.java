package com.computec.carrito;

import com.computec.model.Equipo;

// Comando concreto para eliminar un equipo del carrito
public class EliminarEquipoCommand implements Command {
    private CarritoDeCompras carrito;
    private Equipo equipo;
    private int cantidad;

    public EliminarEquipoCommand(CarritoDeCompras carrito, Equipo equipo, int cantidad) {
        this.carrito = carrito;
        this.equipo = equipo;
        this.cantidad = cantidad;
    }

    @Override
    public void execute() {
        carrito.eliminarEquipo(equipo, cantidad);
    }

    @Override
    public void undo() {
        carrito.agregarEquipo(equipo, cantidad);
    }
}