package com.computec.carrito;

import com.computec.model.Equipo;

// Comando concreto para agregar un equipo al carrito
public class AgregarEquipoCommand implements Command {
    private CarritoDeCompras carrito;
    private Equipo equipo;
    private int cantidad;

    public AgregarEquipoCommand(CarritoDeCompras carrito, Equipo equipo, int cantidad) {
        this.carrito = carrito;
        this.equipo = equipo;
        this.cantidad = cantidad;
    }

    @Override
    public void execute() {
        carrito.agregarEquipo(equipo, cantidad);
    }

    @Override
    public void undo() {
        carrito.eliminarEquipo(equipo, cantidad);
    }
}