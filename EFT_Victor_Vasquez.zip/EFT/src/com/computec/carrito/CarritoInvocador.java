package com.computec.carrito;

// Invocador que maneja la ejecución de comandos
public class CarritoInvocador {
    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void executeCommand() {
        command.execute();
    }

    public void undoCommand() {
        command.undo();
    }
}
