package com.computec.carrito;

import com.computec.model.Equipo;

import java.util.HashMap;
import java.util.Map;

// Clase CarritoDeCompras
public class CarritoDeCompras {
    private Map<Equipo, Integer> items = new HashMap<>();

    public void agregarEquipo(Equipo equipo, int cantidad) {
        items.put(equipo, items.getOrDefault(equipo, 0) + cantidad);
    }

    public void eliminarEquipo(Equipo equipo, int cantidad) {
        int cantidadActual = items.getOrDefault(equipo, 0);
        if (cantidadActual <= cantidad) {
            items.remove(equipo);
        } else {
            items.put(equipo, cantidadActual - cantidad);
        }
    }

    public Map<Equipo, Integer> getItems() {
        return new HashMap<>(items);
    }
}