package com.computec.carrito;

// Interfaz Command
public interface Command {
    void execute();
    void undo();
}