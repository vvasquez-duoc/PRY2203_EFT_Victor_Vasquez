package com.computec.ventas;

// Clase abstracta DecoradorDescuento
public abstract class DecoradorDescuento implements Descuento {
    protected Descuento descuentoDecorado;

    public DecoradorDescuento(Descuento descuentoDecorado) {
        this.descuentoDecorado = descuentoDecorado;
    }

    @Override
    public double aplicarDescuento(double precioOriginal) {
        return descuentoDecorado.aplicarDescuento(precioOriginal);
    }
}