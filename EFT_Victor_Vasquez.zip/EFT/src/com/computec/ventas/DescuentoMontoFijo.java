package com.computec.ventas;

// Implementación de descuento de monto fijo
public class DescuentoMontoFijo extends DecoradorDescuento {
    private double montoFijo;

    public DescuentoMontoFijo(Descuento descuentoDecorado, double montoFijo) {
        super(descuentoDecorado);
        this.montoFijo = montoFijo;
    }

    @Override
    public double aplicarDescuento(double precioOriginal) {
        double precioConDescuentoPrevio = super.aplicarDescuento(precioOriginal);
        return Math.max(0, precioConDescuentoPrevio - montoFijo);
    }
}
