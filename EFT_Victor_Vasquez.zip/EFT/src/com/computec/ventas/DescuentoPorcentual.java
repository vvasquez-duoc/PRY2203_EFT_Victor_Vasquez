package com.computec.ventas;

// Implementación de descuento porcentual
public class DescuentoPorcentual extends DecoradorDescuento {
    private double porcentaje;

    public DescuentoPorcentual(Descuento descuentoDecorado, double porcentaje) {
        super(descuentoDecorado);
        this.porcentaje = porcentaje;
    }

    @Override
    public double aplicarDescuento(double precioOriginal) {
        double precioConDescuentoPrevio = super.aplicarDescuento(precioOriginal);
        return precioConDescuentoPrevio * (1 - porcentaje / 100);
    }
}