package com.computec.ventas;

// Interfaz Descuento
public interface Descuento {
    double aplicarDescuento(double precioOriginal);
}