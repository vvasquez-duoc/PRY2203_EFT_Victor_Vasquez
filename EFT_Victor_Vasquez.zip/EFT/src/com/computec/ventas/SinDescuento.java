package com.computec.ventas;

// Implementación base sin descuento
public class SinDescuento implements Descuento {
    @Override
    public double aplicarDescuento(double precioOriginal) {
        return precioOriginal;
    }
}